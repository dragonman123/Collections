___________________________________________________________________

This resource has been created by Jascha Brinkmann for www.jascha.io
___________________________________________________________________

TERMS OF USE:

You are free to use all resources made available on www.jascha.io for use in both personal and commercial projects. These includes but are not limited to graphics, images, icons, fonts, brushes, shapes, photoshop or illustrator archives, textures, layer styles, web elements and themes.

The resources are free to use, without restriction, in software programs, web templates and other materials intended for sale or distribution. No attribution or backlinks are required, but we would love if you could help us spreading the word.

Its strictly forbidden to make the resources available for distribution elsewhere without prior consent.

___________________________________________________________________

www.jascha.io
